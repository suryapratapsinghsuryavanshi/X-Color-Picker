<img height="50px" src="./images/color-picker.png"/>

# X Color Picker

> A color picker chrome extension with new EyeDropper JavaScript API.

X Color Picker is just a tool for everyone who works with color. Pick eye-catchy colors easily from anywhere.

## Wireframe
![wireframe](./images/wireframe.jpg)

## Final Output
![output](./images/X-Color-Picker.jpg)

<hr>

#### 📑 Project Under construction please give your support and contribution on it.